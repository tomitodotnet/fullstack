import logo from './logo.svg';
import './App.css';

import { useState } from 'react';

const data = [
  { category: "Fruits", price: "$1", stocked: true, name: "Apple" },
  { category: "Fruits", price: "$1", stocked: true, name: "Dragonfruit" },
  { category: "Fruits", price: "$2", stocked: false, name: "Passionfruit" },
  { category: "Vegetables", price: "$2", stocked: true, name: "Spinach" },
  { category: "Vegetables", price: "$4", stocked: false, name: "Pumpkin" },
  { category: "Vegetables", price: "$1", stocked: true, name: "Peas" }
]
function App(props) {

  const currDate = new Date();

  return (
    <div className="App">
      
      <StatefulComponents/>

      
    </div>
  );
}


function StatefulComponents(){
  const  [inputValue, setValue] = useState ("");

  function handleChange (event) {
    setValue(event.target.value)
  }
    
  return (
    <div>
      <input value={inputValue} onChange={handleChange}></input> 
    </div>
  )
  
}

function handleClick(event){
  alert("Hola");
  console.log(event);
}

const handleInputChange = (event) => {
  console.log("input:" , event.target.value)
}

function Button(){
return (
  <div>
  <input onChange={handleInputChange}  defaultValue="Nombre" type="Text"> </input> 
    <button onClick={handleClick}> Hola </button>
  </div>
);
}


function Searcher(){
  return (
    <div className = 'searcher-bar' >
      <div>
        <input type="Text" placeholder='Search aqi...'/> 
      </div>
      <div>
        <input type="checkbox" /> 
        <label> Solo mostrar productos en stock ejemplo</label>

      </div>
      <div>

      </div>
  
    </div>


  );
}

function ProductTable(){
  const tableheader = ["Name", "Price"]
  return (
      <table>
          <thead>
            <ProductTableHeader headers = {tableheader}/>
          </thead>
          <tbody>
         {/*
          <ProductTableHeader headers = {["category"]}/>
          */
         }
            {data.map(p => (<ProductTableRow product = {p}/>)) }
          </tbody>
      </table>
  );
}

function ProductTableHeader({headers}){
  const head = headers.map(header => ( <th> {header} </th>))
  return (
      <tr>
           {head}
      </tr>
  );
}

function ProductTableRow({product}){
  return (
    <tr>
      <td>{product.name}</td>
      <td>{product.price}</td>
    </tr>

  );

  
}


export default App;
