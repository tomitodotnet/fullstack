from django.shortcuts import render
import datetime
from django.shortcuts import HttpResponse
from .models import Cancha
from .models import Persona

from django.views.generic import TemplateView

# Create your views here.

def getInfoCanchaById(request ,id_cancha):
    #obtener cancha por su id
    cancha = Cancha.objects.get(id=id_cancha)
    #result = f"Cancha: {cancha.nombre}, Descripción: {cancha.descripcion} y te cuesta {cancha.costo_por_hora} ."
    #return HttpResponse(result)
    return render(request, "cancha.html", {'nombre': cancha.nombre , 'descripcion': cancha.descripcion})

def getInfoPersonaById(request ,id_persona):
    #obtener Persona por su id
    persona = Persona.objects.get(id=id_persona)
    result = f"Cancha: {persona.nombre}, Descripción: {persona.apellido} y tu correo es {persona.correo} ."
    return HttpResponse(result)

class MainView(TemplateView):
    template_name="main.html"

def getListadoCanchas(request ):
    canchas = Cancha.objects.all()
    nombre_canchas = []
    for cancha in canchas:
        nombre_canchas.append((cancha.id, cancha.nombre))

    return render(request, "canchas.html", {'listado':nombre_canchas})


