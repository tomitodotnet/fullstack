from django.apps import AppConfig


class ReservacanchaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ReservaCancha'
